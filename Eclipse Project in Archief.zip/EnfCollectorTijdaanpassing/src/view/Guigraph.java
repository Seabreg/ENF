/**
 ***************************************************************
 * Guigraph.java ***********************************************
 * *************************************************************
 * De klas Guigraph.java creeert een grafiek die de laatst *****
 * verkregen resultaten uitzet in een grafiek. *****************
 * De methode is aan te roepen doormiddel van: *****************
 * Guigraph(int maxage); ***************************************
 * Met maxage het aantal seconden dat de grafiek aan data ******
 * weergeeft. ************************************************** 
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.ui.RectangleInsets;

@SuppressWarnings("serial")
public class Guigraph extends JPanel {

	public static TimeSeries frequence;
	public static TimeSeries frequence50;
	public static Vector<Float> Frequence = new Vector<Float>();
	public static Vector<Long> Datum = new Vector<Long>();

	@SuppressWarnings("deprecation")
	public Guigraph(int maxAge) throws InterruptedException {

		super(new BorderLayout());
		
		// Create Graph series
		frequence = new TimeSeries("Frequence", Millisecond.class);
		frequence.setMaximumItemAge(maxAge);

		frequence50 = new TimeSeries("50 Hz", Millisecond.class);
		frequence50.setMaximumItemAge(maxAge);

		// Add series to graph		
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(frequence);
		dataset.addSeries(frequence50);
		
		// Set Axis labels
		DateAxis domain = new DateAxis("Time");
		NumberAxis range = new NumberAxis("Frequence");
		
		domain.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 12));
		range.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 12));
		domain.setLabelFont(new Font("SansSerif", Font.PLAIN, 14));
		range.setLabelFont(new Font("SansSerif", Font.PLAIN, 14));

		XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
		renderer.setSeriesPaint(0, Color.yellow);
		renderer.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT,
				BasicStroke.JOIN_BEVEL));

		XYPlot plot = new XYPlot(dataset, domain, range, renderer);
		plot.setBackgroundPaint(Color.DARK_GRAY);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));

		domain.setAutoRange(true);
		domain.setLowerMargin(0.0);
		domain.setUpperMargin(0.0);
		domain.setTickMarksVisible(true);

		range.setStandardTickUnits(NumberAxis.createStandardTickUnits());
		range.setAutoRangeIncludesZero(false);

		// Set chart
		JFreeChart chart = new JFreeChart("ENF Collector", new Font(
				"SansSerif", Font.BOLD, 24), plot, false);
		chart.setBackgroundPaint(getBackground());

		ChartPanel chartPanel = new ChartPanel(chart);
		chartPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory
				.createEmptyBorder(4, 4, 4, 4), BorderFactory
				.createLineBorder(getBackground())));
		add(chartPanel);

	}

}
