/**
 ***************************************************************
 * Gui.java ****************************************************
 * *************************************************************
 * De klas Gui.java verzorgt de gebruikers interface met alle **
 * controle functies voor het verzamelen van ENF data en *******
 * geeft het een grafiek weer **********************************
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import recorder.Capture;
import root.Main;
import checks.checks;
import db.WriteDataCollection;

@SuppressWarnings("serial")
public class Gui extends JFrame {

	public static String absdbpath = null;
	public static float sampleFrequence = 16000.0F; // Default sample frequency
	public static int teller = 0; // Count number of samples collected

	
	// Information Labels visible in GUI
	public static JLabel inputSignalWaarde = new JLabel();
	public static JLabel lastFrequenceWaarde = new JLabel();
	public static JLabel dateCollectedWaarde = new JLabel();
	public static JLabel totalCollectedWaarde = new JLabel();
	public static JLabel errorwaarde = new JLabel("---");

	public Gui() throws InterruptedException {

		JFrame enfCollectorFrame = new JFrame("FrameIcon");
		Image im = Toolkit.getDefaultToolkit().getImage("icon.jpg");
		enfCollectorFrame.setIconImage(im);

		// Create Graph for Live view
		final Guigraph panel2 = new Guigraph(120000);

		setLayout(null);

		JPanel mainPanelCollector = new JPanel();
		mainPanelCollector.setLayout(null);
		mainPanelCollector.setBackground(getBackground());

		// Create panel for error messages
		final JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2, 2));

		// LABELS 
		
			// Database path
		JLabel databasePath = new JLabel("DB-path:");
		databasePath.setBounds(20, 200, 150, 15);
		databasePath.setBackground(getBackground());

		final JLabel databasePathWaarde = new JLabel(absdbpath);
		databasePathWaarde.setBounds(150, 200, 400, 15);
		databasePathWaarde.setForeground(Color.orange);
		databasePathWaarde.setBackground(getBackground());
			
			// Sample frequency
		JLabel sFrequence = new JLabel("Sample Frequence:");
		sFrequence.setBounds(20, 215, 150, 15);
		sFrequence.setBackground(getBackground());
		
		
		final JLabel sFrequenceWaarde = new JLabel(sampleFrequence + " Hz");
		sFrequenceWaarde.setBounds(150, 215, 270, 15);
		sFrequenceWaarde.setForeground(Color.orange);
		sFrequenceWaarde.setBackground(getBackground());

		
			// Inputsignal Check
		JLabel inputSignal = new JLabel("Input signal:");
		inputSignal.setBounds(20, 230, 150, 15);
		inputSignal.setBackground(getBackground());

		inputSignalWaarde.setBounds(150, 230, 270, 15);
		inputSignalWaarde.setForeground(Color.orange);
		inputSignalWaarde.setBackground(getBackground());

			// Date started
		JLabel dateStarted = new JLabel("Date started:");
		dateStarted.setBounds(20, 250, 150, 15);
		dateStarted.setBackground(getBackground());

		final JLabel dateStartedWaarde = new JLabel("");
		dateStartedWaarde.setBounds(150, 250, 270, 15);
		dateStartedWaarde.setForeground(Color.orange);
		dateStartedWaarde.setBackground(getBackground());

		
			// Last recorded frequency
		JLabel lastFrequence = new JLabel("Last Frequence:");
		lastFrequence.setBounds(20, 265, 150, 15);
		lastFrequence.setBackground(getBackground());

		lastFrequenceWaarde.setBounds(150, 265, 270, 15);
		lastFrequenceWaarde.setForeground(Color.orange);
		lastFrequenceWaarde.setBackground(getBackground());

			// Date collected last recorded sample
		JLabel dateCollected = new JLabel("Date collected:");
		dateCollected.setBounds(20, 280, 150, 15);
		dateCollected.setBackground(getBackground());

		dateCollectedWaarde.setBounds(150, 280, 270, 15);
		dateCollectedWaarde.setForeground(Color.orange);
		dateCollectedWaarde.setBackground(getBackground());

			// Total collected samples
		JLabel totalCollected = new JLabel("Total collected:");
		totalCollected.setBounds(20, 295, 150, 15);
		totalCollected.setBackground(getBackground());

		totalCollectedWaarde.setBounds(150, 295, 270, 15);
		totalCollectedWaarde.setForeground(Color.orange);
		totalCollectedWaarde.setBackground(getBackground());

			// Error
		JLabel errors = new JLabel("Error:");
		errors.setBounds(20, 310, 150, 15);
		errors.setBackground(getBackground());

		errorwaarde.setBounds(150, 310, 600, 15);
		errorwaarde.setForeground(Color.red);
		errorwaarde.setBackground(getBackground());
		
		// MENU
		
		// Create menubar
		JMenuBar menubar = new JMenuBar();
		
		// Create menubar items
		JMenu file = new JMenu("File");
		JMenu collector = new JMenu("Collector");
		JMenu tools = new JMenu("Tools");

		// Create submenu items
			// File
		final JMenuItem selectDatabase = new JMenuItem("Select database");
		final JMenuItem newDatabase = new JMenuItem("New database");
		JMenuItem close = new JMenuItem("Close");

			// Collector
		final JMenuItem start = new JMenuItem("Start");
		start.setEnabled(true);
		final JMenuItem stop = new JMenuItem("Stop");
		stop.setEnabled(false);

			// Tools
		final JMenu sampleFrequenceMenu = new JMenu("Sample Frequence");

			// SampleFrequence submenu items
		final JCheckBoxMenuItem SampleFrequence8000 = new JCheckBoxMenuItem(
				"8000 Hz");
		final JCheckBoxMenuItem SampleFrequence11025 = new JCheckBoxMenuItem(
				"11025 Hz");
		final JCheckBoxMenuItem SampleFrequence16000 = new JCheckBoxMenuItem(
				"16000 Hz");
		SampleFrequence16000.setState(true); // 16000 Hz checked by default
		final JCheckBoxMenuItem SampleFrequence22050 = new JCheckBoxMenuItem(
				"22050 Hz");
		final JCheckBoxMenuItem SampleFrequence44100 = new JCheckBoxMenuItem(
				"44100 Hz");

		// ACTIONEVENTS 
		
		// Create new database
		newDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Show Dialog for filename input (without extension)
				String newdatabase = JOptionPane
						.showInputDialog(
								null,
								"Fill in a filename for the database without extension",
								"New Database", JOptionPane.QUESTION_MESSAGE);
				
				// Check if template database exists. If not, show error message.
				if (!new File("_template/dbtemplate.enfdb").exists()) {

					String message = "Can't create new database, template database \n doesn't excist.";
					JOptionPane.showMessageDialog(new JFrame(), message,
							"Error creating new database",
							JOptionPane.ERROR_MESSAGE);
				}
				
				// Check if filename input is empty
				if (!(newdatabase.trim().isEmpty())) {
					
					// Check if template database exists. If not, show error message.
					if (!new File("_template/dbtemplate.enfdb").exists()) {
						
						String message = "Can't create new database, template database \n doesn't excist.";
						JOptionPane.showMessageDialog(new JFrame(), message,
								"Error creating new database",
								JOptionPane.ERROR_MESSAGE);
					}

					try {
						// Create a copy of template and save as filename
						new calculate.CopyFile("_template/dbtemplate.enfdb",
								"collections/" + newdatabase + ".mdb");
					
					} catch (IOException e) {
						e.printStackTrace();
					}

				}

			}
		});

		// Select database for saving results
		selectDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Create a filechooser window	
				JFileChooser fileopen = new JFileChooser();
				// Set current Directory
				fileopen.setCurrentDirectory(new File("collections"));
				// Show only MS Acces (.mdb) files
				FileFilter filter = new FileNameExtensionFilter(
						"MS Access DB (*.mdb)", "mdb");
				fileopen.addChoosableFileFilter(filter);

				int ret = fileopen.showOpenDialog(panel);

				if (ret == JFileChooser.APPROVE_OPTION) {

					try {
						
						File file = fileopen.getSelectedFile();

						String x = file.getCanonicalPath().replaceAll("\\\\",
								"/");

						// Check if there is a mdb file selected
						checks.mdbCheck(x);
						
						//Update information labels in GUI and set database
						databasePathWaarde.setText(x);
						absdbpath = x;

					} catch (Exception e) {
					}

				}

			}
		});
		
		// Closing the program
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Check if recorder is running. If yes.. show error message
				if (stop.isEnabled()) {

					JOptionPane
							.showMessageDialog(
									panel,
									"Please stop collecting ENF data before closing the program.",
									"Error", JOptionPane.ERROR_MESSAGE);

				} else {

					System.exit(0);

				}

			}
		});

		// Start recording
		start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Set state labels null
				teller = 0;
				inputSignalWaarde.setText(null);
				dateStartedWaarde.setText(null);
				lastFrequenceWaarde.setText(null);
				dateCollectedWaarde.setText(null);
				totalCollectedWaarde.setText(null);
				errorwaarde.setText(null);
				Guigraph.frequence.clear();

				// Empty xFreq buffer
				while (WriteDataCollection.xFreq.size() != 0) {

					WriteDataCollection.xFreq.removeElementAt(0);

				}
				
				// Empty xDatum buffer
				while (WriteDataCollection.xDatum.size() != 0) {

					WriteDataCollection.xDatum.removeElementAt(0);

				}
				
				// Check if database is selected. If not show error message.
				if (!(absdbpath == null)) {
					
					// Check if selected database excists. If not show error message.
					if (new File(Gui.absdbpath).exists()) {

						// Get start time
						String starttijddatum = new SimpleDateFormat(
								"dd/MM/yyyy HH:mm:ss").format(new Date());
						dateStartedWaarde.setText(starttijddatum);

						// Create Capture object and execute in thread
						Main.executor.execute(new Capture());
						
						// Change menu item state
						start.setEnabled(false);
						stop.setEnabled(true);
						selectDatabase.setEnabled(false);
						newDatabase.setEnabled(false);
						sampleFrequenceMenu.setEnabled(false);

					} else {

						absdbpath = null;

						JOptionPane.showMessageDialog(panel,
								"The selected database doesn't excist",
								"Error", JOptionPane.ERROR_MESSAGE);

					}

				} else {

					JOptionPane.showMessageDialog(panel,
							"Please select a database first.", "Error",
							JOptionPane.ERROR_MESSAGE);

				}

			}
		});

		// Stop recording
		stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Show confimation dialog
				int res = JOptionPane.showConfirmDialog(getContentPane(),
						"Are you sure to stop collecting ENF data?",
						"Need Confirmation", JOptionPane.YES_NO_OPTION);
				
				// If confirmed.. Stop recording
				if (res == JOptionPane.YES_OPTION) {

					Capture.running = false;

					start.setEnabled(true);
					stop.setEnabled(false);
					selectDatabase.setEnabled(true);
					newDatabase.setEnabled(true);
					sampleFrequenceMenu.setEnabled(true);

				}

			}
		});

		// Set sample frequency 8000 Hz
		SampleFrequence8000.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				SampleFrequence8000.setState(true);
				SampleFrequence11025.setState(false);
				SampleFrequence16000.setState(false);
				SampleFrequence22050.setState(false);
				SampleFrequence44100.setState(false);

				sampleFrequence = 8000.0F;
				sFrequenceWaarde.setText("8000 Hz");

			}
		});

		// Set sample frequency 11025 Hz
		SampleFrequence11025.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				SampleFrequence8000.setState(false);
				SampleFrequence11025.setState(true);
				SampleFrequence16000.setState(false);
				SampleFrequence22050.setState(false);
				SampleFrequence44100.setState(false);

				sampleFrequence = 11025.0F;
				sFrequenceWaarde.setText("11025 Hz");

			}
		});

		// Set sample frequency 16000 Hz
		SampleFrequence16000.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				SampleFrequence8000.setState(false);
				SampleFrequence11025.setState(false);
				SampleFrequence16000.setState(true);
				SampleFrequence22050.setState(false);
				SampleFrequence44100.setState(false);

				sampleFrequence = 16000.0F;
				sFrequenceWaarde.setText("16000 Hz");

			}
		});

		// Set sample frequency 22050 Hz
		SampleFrequence22050.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				SampleFrequence8000.setState(false);
				SampleFrequence11025.setState(false);
				SampleFrequence16000.setState(false);
				SampleFrequence22050.setState(true);
				SampleFrequence44100.setState(false);

				sampleFrequence = 22050.0F;
				sFrequenceWaarde.setText("22050 Hz");

			}
		});

		// Set sample frequency 44100 Hz
		SampleFrequence44100.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				SampleFrequence8000.setState(false);
				SampleFrequence11025.setState(false);
				SampleFrequence16000.setState(false);
				SampleFrequence22050.setState(false);
				SampleFrequence44100.setState(true);

				sampleFrequence = 44100.0F;
				sFrequenceWaarde.setText("44100 Hz");

			}
		});

		// Add menu items to menubar
		file.add(selectDatabase);
		file.add(newDatabase);
		file.add(close);

		collector.add(start);
		collector.add(stop);

		tools.add(sampleFrequenceMenu);
		
		sampleFrequenceMenu.add(SampleFrequence8000);
		sampleFrequenceMenu.add(SampleFrequence11025);
		sampleFrequenceMenu.add(SampleFrequence16000);
		sampleFrequenceMenu.add(SampleFrequence22050);
		sampleFrequenceMenu.add(SampleFrequence44100);

		menubar.add(file);
		menubar.add(collector);
		menubar.add(tools);

		// Add menubar to frame
		enfCollectorFrame.setJMenuBar(menubar);

		// Add labels to panel
		mainPanelCollector.add(databasePath);
		mainPanelCollector.add(sFrequence);
		mainPanelCollector.add(inputSignal);

		mainPanelCollector.add(dateStarted);
		mainPanelCollector.add(lastFrequence);
		mainPanelCollector.add(dateCollected);
		mainPanelCollector.add(totalCollected);

		mainPanelCollector.add(databasePathWaarde);
		mainPanelCollector.add(sFrequenceWaarde);
		mainPanelCollector.add(inputSignalWaarde);

		mainPanelCollector.add(dateStartedWaarde);
		mainPanelCollector.add(lastFrequenceWaarde);
		mainPanelCollector.add(dateCollectedWaarde);
		mainPanelCollector.add(totalCollectedWaarde);
		mainPanelCollector.add(errors);
		mainPanelCollector.add(errorwaarde);

		// Make panel for graph visible
		enfCollectorFrame.getContentPane().add(panel2, BorderLayout.CENTER);
		enfCollectorFrame.setBounds(200, 120, 600, 250);
		enfCollectorFrame.setVisible(true);

		// Show GUI
		enfCollectorFrame.add(mainPanelCollector);
		enfCollectorFrame
				.setTitle("ENF Collector | Nederlands Forensisch Instituut");
		enfCollectorFrame.setSize(600, 400);
		enfCollectorFrame.setResizable(false);
		enfCollectorFrame.setLocationRelativeTo(null);
		enfCollectorFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		enfCollectorFrame.setVisible(true);

	}

}
