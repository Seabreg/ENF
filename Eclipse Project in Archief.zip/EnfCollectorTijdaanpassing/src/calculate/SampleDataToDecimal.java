/**
 ***************************************************************
 * SampleDataToDecimal.java ************************************
 * *************************************************************
 * De data in de byte array bestaat uit hexadecimale waarden. **
 * Om hier makkelijk aan te kunnen rekenen worden deze omgezet *
 * naar decimaal. Na het omzetten wordt de data doorgestuurd ***
 * naar de methode CalculateZeroCrossings(data, datum) waar de *
 * periode van iedere trilling wordt berekend. ***************** 
 * *************************************************************
 * Input: ******************************************************
 * - byte[], datum *********************************************
 * *************************************************************
 * Output: *****************************************************
 * - int[], datum  *********************************************
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package calculate;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import root.Main;
import view.Gui;

public class SampleDataToDecimal implements Runnable {

	static final byte[] HEX_CHAR_TABLE = { (byte) '0', (byte) '1', (byte) '2',
			(byte) '3', (byte) '4', (byte) '5', (byte) '6', (byte) '7',
			(byte) '8', (byte) '9', (byte) 'a', (byte) 'b', (byte) 'c',
			(byte) 'd', (byte) 'e', (byte) 'f' };

	
	public SampleDataToDecimal(byte[] sampleData, long datum)
			throws IOException, InterruptedException {

		// Check if array with sample data is complete. (Always even) 
		if (sampleData.length % 2 != 0) {

			System.out
					.println("ERROR: Sampledata isn't complete -- Odd count off bytes.");

		}
		
		// Create a string from byte array sampledata
		String r = getHexString(sampleData);

		String[] string = new String[r.length() / 2];

		int k = 0;
		int l = 2;

		// Cut String into pieces of 2 bytes and add them to String[]
		for (int i = 0; i < r.length() / 2; i++) {

			string[i] = r.substring(k, l);

			l = l + 2;
			k = k + 2;
		}

		int[] data = new int[string.length];

		// Write new data array
		for (int z = 0; z < string.length - 1; z++) {

			// Convert hex to dec
			int x = hex2dec(string[z] + string[++z]);

			z--;

			data[z] = x;

		}
		
		// Check the intensity of the input signal
		boolean s = checks.Inputchecker.toSoft(data);
		boolean h = checks.Inputchecker.toHard(data);

		if (s || h) {

			if (s) {

				Gui.inputSignalWaarde.setText("To Low");
			}

			if (h) {

				Gui.inputSignalWaarde.setText("To High");
			}

		} else {

			Gui.inputSignalWaarde.setText("OK");
			
			// If input is OK, calculate the period of each wave
			Main.executor.execute(new CalculateZeroCrossings(data, datum));

		}

	}

	// Get String from byte[]
	public static String getHexString(byte[] raw)
			throws UnsupportedEncodingException {
		byte[] hex = new byte[2 * raw.length];
		int index = 0;

		for (byte b : raw) {
			int v = b & 0xFF;
			hex[index++] = HEX_CHAR_TABLE[v >>> 4];
			hex[index++] = HEX_CHAR_TABLE[v & 0xF];
		}
		return new String(hex, "ASCII");
	}

	// Convert hex to dec
	public static int hex2dec(String s) {

		int intValue = Integer.parseInt(s, 16);

		return intValue;

	}

	public void run() {

	}
}
