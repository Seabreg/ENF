/**
 ***************************************************************
 * CalculateZeroCrossings.java *********************************
 * *************************************************************
 * De CalculateZeroCrossings klas berekent de gemiddelde *******
 * sample data en vergelijkt daar daarna alle sample data mee **
 * om te bepalen waar ze elkaar doorkruisen. *******************
 * Wanneer de doorgangen bekent zijn worden de frequenties en **
 * daarvan de gemiddelde frequentie berekent. ******************
 * *************************************************************
 * INPUT: ******************************************************
 * - Decimale data in de vorm van een int array ****************
 * - Opname datum **********************************************
 * *************************************************************
 * OUTPUT: *****************************************************
 * - Gemiddelde frequentie *************************************
 * - Opname datum **********************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package calculate;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;

import org.jfree.data.time.Millisecond;

import recorder.Capture;
import root.Main;
import view.Gui;
import view.Guigraph;
import db.WriteDataCollection;

public class CalculateZeroCrossings implements Runnable {

	@Override
	public void run() {
	}

	public CalculateZeroCrossings(int[] data, long datum) throws IOException,
			InterruptedException {

		getZeroCross(data, getAverage(data), datum);

	}

	// Calculate average sample data
	public float getAverage(int[] data) {

		int total = 0;
		float average;

		for (int i = 0; i < data.length - 1; i++) {

			total = total + data[i];

		}

		average = total / (float) (data.length);

		return average;

	}

	// Calculate the frequency from crossings
	public float[] getFrequency(Vector<Float> zeroCrossings, long datum)
			throws FileNotFoundException {

		float[] frequencys = new float[zeroCrossings.size() - 1];

		for (int i = 0; i < zeroCrossings.size() - 1; i++) {

			// Calculate time for each sample
			float sampleTime = 1 / Capture.getFormat().getSampleRate();

			// Calculate time between crossings
			float halveTrillingsTijd = (zeroCrossings.elementAt(i + 1)
					.floatValue() - zeroCrossings.elementAt(i).floatValue())
					* sampleTime;

			// Calculate frequency for each half period
			float frequency = (1 / halveTrillingsTijd) / 2;

			// Add frequency to array
			frequencys[i] = frequency;

		}

		return frequencys;

	}

	// Calculate the crossings between the sample data and the average sample
	// data
	public Vector<Float> getZeroCross(int[] data, float average, long datum)
			throws InterruptedException, IOException {

		Vector<Float> zeroCrossings = new Vector<Float>();

		for (int i = 0, z = 1; i < data.length - 1; i++, z++) {

			// Check if first sample data is bigger than average and the second
			// sample data is smaller than the average
			if (data[i] > average && data[z] < average) {

				float zeroCross = i
						+ (1 / ((data[i] - data[z]) / (data[i] - average)));

				zeroCrossings.add(zeroCross);

			}

			// Check if first sample data is smaller than average and the second
			// sample data is bigger than the average
			if (data[i] < average && data[z] > average) {

				float zeroCross = z
						- (1 / ((data[z] - data[i]) / (data[z] - average)));

				zeroCrossings.add(zeroCross);

			}

			// Check if sample data is equal to the average sample data
			if (data[i] == average) {

				float zeroCross = (float) i;

				zeroCrossings.add(zeroCross);

			}

		}

		// Calculate the frequencys from the crossings and the average frequency
		getAverageFrequency(getFrequency(zeroCrossings, datum), datum);

		return null;

	}

	// Calculate the average frequency
	private void getAverageFrequency(float[] freqs, long datum)
			throws InterruptedException, IOException {

		int aantal = 0;
		float som = 0;

		for (int i = 0; i < freqs.length; i++) {

			// For calculating the average, use only the frequencys between 49.0
			// and 51.0 Hz
			if (freqs[i] > 49.0F && freqs[i] < 51.0F) {

				som = som + freqs[i];
				aantal++;

			}

		}

		// Calculate average frequency
		float average = som / aantal;

		// Update GUI information
		Date resultdate = new Date(datum);
		Gui.dateCollectedWaarde.setText("" + resultdate);
		Gui.lastFrequenceWaarde.setText("" + average);

		// Add average frequency to vector, waiting for export to database.
		WriteDataCollection.xFreq.add(average);
		WriteDataCollection.xDatum.add(datum);

		// Add data to live graph
		Guigraph.frequence.addOrUpdate(new Millisecond(resultdate), average);
		Guigraph.frequence50.addOrUpdate(new Millisecond(resultdate), 50);

		// Call method for writing data to database
		Main.scheduler.execute(new WriteDataCollection());

	}
}
