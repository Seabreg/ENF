package checks;

public class Inputchecker {

	// If difference between biggest and lowest data sample is higher than 80000
	// the the input intensity is to high 
	public static boolean toHard(int[] b) {

		boolean c;

		c = (max(b) - min(b)) > 80000;

		return c;
	}

	// If difference between biggest and lowest data sample is lower than 0
	// the the input intensity is to high 
	public static boolean toSoft(int[] b) {

		boolean c;

		c = (max(b) - min(b)) < 0;

		return c;
	}

	// Get biggest data sample from array
	public static int max(int[] t) {
		int maximum = t[0];
		for (int i = 1; i < t.length - 1; i++) {
			if (t[i] > maximum) {
				maximum = t[i];
			}

		}
		return maximum;
	}

	// Get smallest data sample from array
	public static int min(int[] t) {
		int minimum = t[0];
		for (int i = 1; i < t.length - 1; i++) {
			if (t[i] < minimum) {
				minimum = t[i];
			}

		}

		return minimum;
	}

}
