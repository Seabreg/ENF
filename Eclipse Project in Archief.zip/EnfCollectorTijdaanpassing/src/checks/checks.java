package checks;

import java.awt.GridLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import view.Gui;

public class checks {

	
	// Check if selected file is a MS Access database
	public static void mdbCheck(String dbpath) {

		final JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2, 2));

		int dotPos = dbpath.lastIndexOf(".");
		String extension = dbpath.substring(dotPos);

		if (extension.equals(".mdb")) {

			Gui.absdbpath = dbpath;

		} else {

			JOptionPane.showMessageDialog(panel,
					"Please select een MS Access database (*.mdb)", "Error",
					JOptionPane.ERROR_MESSAGE);

		}

	}
	
	// Check if filename include extension .mdb. If not, add extension .mdb.
	public static String addExtension(String x){
		
		String z = x.substring(x.length() - 4, x.length());

		if (!z.contentEquals(".mdb")) {

			x = x + ".mdb";

		}
		
		return x;
		
		
	}

}
