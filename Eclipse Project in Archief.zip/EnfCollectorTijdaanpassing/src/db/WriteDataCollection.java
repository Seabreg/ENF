/**
 ***************************************************************
 * WriteDataCollection.java ************************************
 * *************************************************************
 * De klas WriteDataCollection.java zorgt ervoor dat de ********
 * resultaten steeds per 10 worden weggeschreven naar de *******
 * database. ***************************************************
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package db;

import java.sql.SQLException;
import java.util.Vector;

import view.Gui;

public class WriteDataCollection implements Runnable {

	// Create vectors for temporary stock of average frequencys
	public static Vector<Float> xFreq = new Vector<Float>();
	public static Vector<Long> xDatum = new Vector<Long>();

	// Write 10 results at once.
	protected final int TOTAL_SAMPLES_PER_WRITE = 10;

	public void run() {

		if (xFreq.size() >= TOTAL_SAMPLES_PER_WRITE) {

			new dbconn();

			for (int i = 0; i < TOTAL_SAMPLES_PER_WRITE; i++) {

				try {
					// insert results into database
					dbconn
							.insertIntoDB(xFreq.elementAt(0), xDatum
									.elementAt(0));
					
					// delete result from stock
					xFreq.removeElementAt(0);
					xDatum.removeElementAt(0);

				} catch (SQLException e) {
					e.printStackTrace();

				}

			}

			try {
				
				// Close database connection
				dbconn.closeDB();
			
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
		
		// Update GUI information. Total Collected samples
		Gui.teller++;
		Gui.totalCollectedWaarde.setText("" + Gui.teller);

	}

}
