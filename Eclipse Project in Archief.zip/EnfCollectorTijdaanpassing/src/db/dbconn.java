/**
 ***************************************************************
 * dbconn.java *************************************************
 * *************************************************************
 * De klas dbconn.java zorgt voor een verbinding met de ********  
 * database. En bevat de functie om data naar database weg te **
 * schrijven. **************************************************
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import recorder.Capture;

import view.Gui;

public class dbconn {

	private static Connection connection;
	private static Statement toevoegen;
	
	// Create database connection	
	public dbconn() {

		String errortime = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
		
		// Check if database excists. If not show error message.
		if (new File(Gui.absdbpath).exists()) {

			try {
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver").newInstance();
				connection = DriverManager
						.getConnection("jdbc:odbc:DRIVER={Microsoft Access Driver (*.mdb)};DBQ="
								+ Gui.absdbpath);
				toevoegen = connection.createStatement();
				Gui.errorwaarde.setText("");

			} catch (Exception err) {
				System.out.println("Error: " + err);
				Gui.errorwaarde
						.setText(errortime + ": Database communication failed. Please restart the program.");
			}

		} else {

			Gui.errorwaarde
					.setText(errortime + ": Database is missing. Check database location.");
			Capture.running = false;

		}

	}
	
	// Insert data into the database
	public static void insertIntoDB(float frequentie, long datum)
			throws SQLException {

		toevoegen
				.executeUpdate("INSERT INTO Enf (Frequentie, DatumTijd) VALUES("
						+ frequentie + ", '" + datum + "')");

	}

	// Close database connection
	public static void closeDB() throws SQLException {

		toevoegen.close();
		connection.close();

	}

}
