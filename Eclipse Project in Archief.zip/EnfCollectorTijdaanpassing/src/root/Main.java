/**
 ***************************************************************
 * Main.java ***************************************************
 * *************************************************************
 * De klas Main.java is het startpunt voor het opstarten van ***
 * de ENF Collector. Doormiddel van deze class wordt er een ****
 * recorder gecree�rd voor het opnemen van een ENF database. ***
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package root;

import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import view.Gui;

public class Main {

	// Create Executorpool for multiple Threads
	public static ExecutorService executor = Executors.newFixedThreadPool(3);
	public final static ScheduledExecutorService scheduler = Executors
			.newScheduledThreadPool(1);

	public static void main(String[] args) throws InterruptedException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException, SQLException {

		// Create a Recorder
		new Gui();
		
		executor.awaitTermination(20, TimeUnit.SECONDS);

	}

}
