/**
 ***************************************************************
 * Capture.java ************************************************
 * *************************************************************
 * De Capture class is verantwoordelijk voor het opnemen van ***
 * data vanaf de microfoonpoort op de computer. ****************
 * De data die word opgenomen wordt opgeslagen in een buffer ***
 * welke steeds wanneer de buffer vol is doorgestuurd wordt ****
 * naar de class FillQueue die de frequenties berekent. ********
 * *************************************************************
 * Input: ******************************************************
 * - Elektrisch signaal van de microfoon poort *****************
 * *************************************************************
 * Output: *****************************************************
 * - Buffer met sample data ************************************
 * *************************************************************
 * Note: *******************************************************
 * Voor het opnemen van ENF kan er een draad met wisselstroom, *
 * die doormiddel van weerstanden verzwakt is, vanuit het ******
 * stopcontact in de microfoon poort worden gestopt. ***********
 * Let op! maximaal 1 Volt anders gaat de geluidskaart kapot. **
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package recorder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Calendar;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

import view.Gui;

public class Capture implements Runnable {

	public static boolean running;
	private static ByteArrayOutputStream out;

	public void run() {

		try {

			// Create line for recording
			final AudioFormat format = getFormat();
			DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
			final TargetDataLine line = (TargetDataLine) AudioSystem
					.getLine(info);
			
			// Set buffer size
			int bufferSize = (int) format.getSampleRate()
					* format.getFrameSize();
			byte buffer[] = new byte[bufferSize];

			out = new ByteArrayOutputStream();
			running = true;
			
			// Start recording
			line.open(format);
			line.start();

			while (running) {

				// Set time recorded for data in the buffer
				Calendar now = Calendar.getInstance();
				long x = now.getTimeInMillis();
				
				// Record data from line into buffer
				line.read(buffer, 0, buffer.length);

				// Call FillQueue for calculating the average frequency
				new FillQueue(buffer, x);

			}

			out.close();

		} catch (LineUnavailableException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	// Set audio format
	public static AudioFormat getFormat() {
		float sampleRate = Gui.sampleFrequence;
		int sampleSizeInBits = 8;
		int channels = 1;
		boolean signed = false;
		boolean bigEndian = true;
		return new AudioFormat(sampleRate, sampleSizeInBits, channels, signed,
				bigEndian);
	}

}
