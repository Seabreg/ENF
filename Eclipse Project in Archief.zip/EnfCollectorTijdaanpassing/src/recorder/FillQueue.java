/**
 ***************************************************************
 * FillQueue.java ************************************************
 * *************************************************************
 * De klas FillQueue.java leest de buffer uit en plaats de *****
 * data in een byte array. Daarna wordt de array doorgestuurd **
 * naar de methode SampleDataToDecimal, die er voor zorgt dat **
 * de hexadecimale data in de array wordt omgezet naar *********
 * decimalen.
 * *************************************************************
 * Input: ******************************************************
 * - buffer ****************************************************
 * *************************************************************
 * Output: *****************************************************
 * - byte[] ****************************************************
 * *************************************************************
 * *************************************************************
 * (c) Kevin van Cleef - Nederlands Forensisch Instituut (c) ***
 * Contact @ kevinvancleef@gmail.com ***************************
 * *************************************************************
 ***************************************************************
 */

package recorder;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import root.Main;
import calculate.*;

@SuppressWarnings("unused")
public class FillQueue implements Runnable {

	public FillQueue(byte[] buffer, long datum) throws IOException, InterruptedException {

		int r;
		int i = 0;
		byte[] sampleData = new byte[buffer.length];
		
		InputStream input = new ByteArrayInputStream(buffer);

		// Copy data from buffer into byte array
		while ((r = input.read()) != -1) {

			sampleData[i] = (byte) r;

			i++;
		}

		// Call class for converting hex to dec
		Main.executor.execute(new SampleDataToDecimal(sampleData, datum));

		input.close();

	}

	public void run() {

	}

}
